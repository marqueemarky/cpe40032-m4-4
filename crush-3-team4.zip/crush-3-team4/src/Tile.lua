--[[
   CMPE40032
    Candy Crush Clone (Match 3 Game)

    -- Tile Class --



    The individual tiles that make up our game board. Each Tile can have a
    color and a variety, with the varietes adding extra points to the matches.
]]

Tile = Class{}

function Tile:init(x, y, color, variety, shine)
    -- board positions
    self.gridX = x
    self.gridY = y

    blink = 1
    addblink = true
    self.shine = shine

    -- coordinate positions
    self.x = (self.gridX - 1) * 32
    self.y = (self.gridY - 1) * 32

    psystem = love.graphics.newParticleSystem(gTextures['particle'], 64)
    psystem:setParticleLifetime(2) -- Particles live at least 2s and at most 5s.
    psystem:setLinearAcceleration(-5, -5, 0, 0) -- Randomized movement towards the bottom of the screen.
	psystem:setColors(255, 255, 255, 255, 255, 255, 255, 0) -- Fade to black.

    -- tile appearance/points
    self.color = color
    self.variety = variety
    aaaa = 0
end

function Tile:update(dt)
    psystem:update(dt)
    Timer.every(2,function()        
        if addblink then
            blink = blink + dt
            if blink > 150 then
                addblink = not addblink
            end
        else
            blink = blink - dt
            if blink < 1 then
                addblink = not addblink
            end
        end
    end)
end

--[[
    Function to swap this tile with another tile, tweening the two's positions.
]]
function Tile:swap(tile)

end

function Tile:render(x, y)
    -- draw shadow
    love.graphics.setColor(34, 32, 52, 255)
    love.graphics.draw(gTextures['main'], gFrames['tiles'][self.color][self.variety],
        self.x + x + 2, self.y + y + 2)

    -- draw tile itself
    love.graphics.setColor(255, 255, 255, 255)
    love.graphics.draw(gTextures['main'], gFrames['tiles'][self.color][self.variety],
        self.x + x, self.y + y)
    if self.shine == 1 or self.shine == 2 then
        love.graphics.setColor(255, 250, 250, blink)
        love.graphics.rectangle('fill', self.x + x, self.y + y, 32, 32, 6)
    end

    
end